use std::os::fd::{IntoRawFd, FromRawFd, RawFd};
use std::{fs, os::linux::fs::MetadataExt};
use std::path::{Path, PathBuf};
use std::time::{Duration};
use fuse_mt::*;
use openssl::symm::{Cipher};
use log::{debug, error};

use libc;

// const BLOCK_SIZE: usize = 16;
const AES_128_KEY_SIZE: usize = 16;
const AES_256_KEY_SIZE: usize = 32;

const TTL: Duration = Duration::from_secs(1);

pub struct CryptFS   {
    cipher: Cipher,
    key: String,
    src_dir: PathBuf,
}

impl CryptFS {

    pub fn new(key: String, src_dir_path: String) -> Self {
        // check directory exists
        if !fs::metadata(src_dir_path.clone()).is_ok() {
            error!("Directory does not exist");
            panic!();
        }

        let src_dir = PathBuf::from(src_dir_path).canonicalize().unwrap();

        let cipher: Cipher;
        if key.as_bytes().len() == AES_128_KEY_SIZE {
            cipher = Cipher::aes_128_cbc();
        } else if key.as_bytes().len() == AES_256_KEY_SIZE {
            cipher = Cipher::aes_256_cbc();
        } else {
            panic!("Invalid key size");
        }
    
        return CryptFS {
            cipher: cipher,
            key: key,
            src_dir: src_dir,
        };
    }

    fn check_path(&self, path: &Path) -> Result<(), libc::c_int> {
        if (path.is_dir()|| path.is_file()) && !path.is_symlink() {
            // check if file a regular file or directory
            return Ok(());
        } else {
            return Err(libc::ENOENT);
        }
    }

    fn check_dir(&self, path: &Path) -> Result<(), libc::c_int> {
        if path.is_dir() && !path.is_symlink() {
            // check if file a regular file or directory
            return Ok(());
        } else {
            return Err(libc::ENOTDIR);
        }
    }

    pub fn get_real_path(&self, path: &Path) -> PathBuf {
        let mut real_path = self.src_dir.clone();
        real_path.push(path.strip_prefix("/").unwrap());
        return real_path;
    }

    

}


impl FilesystemMT for CryptFS {
    fn init(&self, _req: RequestInfo) -> ResultEmpty {
        debug!("init() called");
        return Ok(());
    }

    fn destroy(&self) {
        debug!("destroy() called");
    }

    fn getattr(&self, _req: RequestInfo, _path: &Path, _fh: Option<u64>) -> ResultEntry {
        debug!("getattr() called");
        let real_path = self.get_real_path(_path);
        self.check_path(&real_path)?;       // don't follow symlinks, or special files

        match fs::metadata(real_path) {
            Ok(metadata) => {
                let f_attr = FileAttr {
                    size: metadata.len(),
                    blocks: metadata.st_blocks(),
                    atime: metadata.accessed().unwrap(),
                    mtime: metadata.modified().unwrap(),
                    ctime: metadata.accessed().unwrap(),
                    crtime: metadata.accessed().unwrap(),       // linux doesn't have creation time
                    kind: if metadata.is_dir() { FileType::Directory } else { FileType::RegularFile },
                    perm: (metadata.st_mode() & 0xffff) as u16,
                    nlink: metadata.st_nlink() as u32,
                    uid: metadata.st_uid(),
                    gid: metadata.st_gid(),
                    rdev: metadata.st_rdev() as u32,
                    flags: 0        // macOS only, not supported on linux
                };

                return Ok((TTL, f_attr));
            },
            Err(_) => {
                return Err(libc::ENOENT);
            }
        }
        
    }

    // fn opendir(&self, _req: RequestInfo, _path: &Path, _flags: u32) -> ResultOpen {
    //     return Err(libc::ENOSYS);
    // }

    fn opendir(&self, _req: RequestInfo, _path: &Path, _flags: u32) -> ResultOpen {
        debug!("opendir() called");
        let real_path = self.get_real_path(_path);
        self.check_dir(&real_path)?;
        
        let handle = fs::File::open(real_path).unwrap().into_raw_fd() as u64;
        return Ok((handle, 0));
    }

    fn releasedir(&self, _req: RequestInfo, _path: &Path, _fh: u64, _flags: u32) -> ResultEmpty {
        debug!("releasedir() called");
        
        let f = unsafe{ fs::File::from_raw_fd(_fh as RawFd) };
        drop(f);
        return Ok(());
    }

    fn readdir(&self, _req: RequestInfo, _path: &Path, _fh: u64) -> ResultReaddir {
        Err(libc::ENOSYS)
    }

}
